#include <iostream>
#include <vector>
using namespace std;

// Computes the sum of elements list[i]..list[n-1]
// n is assumed to be the size of the list, i.e., list.size()
int sum_list(vector<int> list, int i)
{
	if (i == list.size())
		return 0;
	else
		return list[i] + sum_list(list, i + 1);
}


int main()
{
	vector<int> a;
	int x;
	while (cin >> x) {
		a.push_back(x);
	}

	// Note that the parameter i is set to zero to process the entire
	// elements.
	cout << "sum = " << sum_list(a, 0) << endl;
}
