#include <iostream>
#include <vector>
using namespace std;

double f(vector<double> a, int i) {
	// a[i]*a[i+1] + a[i+2]*a[i+3] + ...
	
	if (i >= a.size())
		return 0;
		
	if (i == a.size() - 1)
		return a[i];
	
	return a[i]*a[i+1] + f(a, i+2);
}

double g(vector<double> a, int i) {
	// a[i]*a[i+1] + a[i+2]/a[i+3] + ...
	if (i >= a.size())
		return 0;
		
	if (i == a.size() - 1)
		return a[i];
	
	double x = i % 4 == 0 ? a[i]*a[i+1] : a[i]/a[i+1];
	return x + g(a, i+2);
}

int main() {
	vector<double> a;  // 3, 4, 6, 2, 7
	a.push_back(3);
	a.push_back(4);
	a.push_back(6);
	a.push_back(2);
	a.push_back(7);
	
	cout << g(a, 0) << endl;  // 22
}








