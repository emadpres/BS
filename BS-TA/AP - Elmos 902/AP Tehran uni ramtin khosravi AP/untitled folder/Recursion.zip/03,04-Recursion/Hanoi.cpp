#include <iostream>
#include <vector>
using namespace std;

// Each peg is modeled as a vector of integers. Each integer
// specifies the size of the disc.
vector<int> a;
vector<int> b;
vector<int> c;

void print_peg(vector<int> peg)
{
	for (int i = 0; i < peg.size(); i++)
		cout << peg[i] << ' ';
	cout << '\n';
}

void print_pegs()
{
	cout << "A: ";
	print_peg(a);
	cout << "B: ";
	print_peg(b);
	cout << "C: ";
	print_peg(c);
	cout << endl;
}

// Moves the topmost disc from 'from_peg' to 'to_peg'. Note that
// the two vectors are passed by reference, since their content
// changes during the operation. The contents of all three vectors
// are printed after each move.
void move(vector<int>& from_peg, vector<int>& to_peg)
{
	to_peg.push_back(from_peg.back());
	from_peg.pop_back();
	print_pegs();
}

// Moves 'num_of_discs' discs from 'from' to 'to' using 'temp'
void hanoi(vector<int>& from, vector<int>& to, vector<int>& temp, int num_of_discs)
{
	if (num_of_discs == 1)
		move(from, to);
	else {
		hanoi(from, temp, to, num_of_discs - 1);
		move(from, to);
		hanoi(temp, to, from, num_of_discs - 1);
	}	
}

int main()
{
	int num_of_discs;
	cout << "How many discs? ";
	cin >> num_of_discs;

	for (int i = num_of_discs; i >= 1; i--)
		a.push_back(i);

	print_pegs();
	hanoi(a, b, c, num_of_discs);
}
