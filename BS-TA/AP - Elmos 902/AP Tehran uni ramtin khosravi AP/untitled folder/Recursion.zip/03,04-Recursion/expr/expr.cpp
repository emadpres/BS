#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;

bool is_number(string s) {
	return s.find_first_of("()+-*/") == -1;
}

int find_operator_pos(string w) {
	int operator_pos = -1;
	if (w[0] != '(')
		operator_pos = w.find_first_of("+-*/");
	else { // look for the closing parenthesis
		int paren_level = 0;
		int j = 0;
		while (j < w.length()) {
			if (w[j] == '(')
				paren_level++;
			else if (w[j] == ')') {
				paren_level--;
				if (paren_level == 0)
					break;
			}
			j++;
		}
		operator_pos = j + 1;
	}
	return operator_pos;
}

int evaluate(string s)
{
	if (is_number(s))
		return atoi(s.c_str());
		
	string w = s.substr(1, s.length() - 2);	// remove the enclosing parentheses
	int operator_pos = find_operator_pos(w);
	
	switch (w[operator_pos]) {
	case '+':
		return evaluate(w.substr(0, operator_pos)) + evaluate(w.substr(operator_pos + 1));
	case '-':
		return evaluate(w.substr(0, operator_pos)) - evaluate(w.substr(operator_pos + 1));
	case '*':
		return evaluate(w.substr(0, operator_pos)) * evaluate(w.substr(operator_pos + 1));
	case '/':
		return evaluate(w.substr(0, operator_pos)) / evaluate(w.substr(operator_pos + 1));
	}
}

int main()
{
	string line;
	while (cin >> line) {
		cout << line << "=" << evaluate(line) << endl;
	}
}
