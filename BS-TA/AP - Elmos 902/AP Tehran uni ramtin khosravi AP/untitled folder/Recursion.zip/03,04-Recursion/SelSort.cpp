#include <iostream>
#include <vector>
using namespace std;

// swaps the contents of two integer variables
void swap(int& a, int& b)
{
	int temp = a;
	a = b;
	b = temp;
}


// Finds the index of the smallest element among list[i]..list[n-1]
// n is assumed to be the size of the list, i.e., list.size()
int min_index(vector<int> list, int i)
{
	if (i == list.size() - 1)	// the last element reached
		return i;
	else {
		int min_idx_rest = min_index(list, i + 1);
		if (list[i] < list[min_idx_rest])
			return i;
		else
			return min_idx_rest;
	}
}

// Sorts the elements list[i]..list[n-1] with selection sort algorithm.
// n is assumed to be the size of the list, i.e., list.size()
// Note that list is passed by reference, since its elements are
// changed during the algorithm.
void selection_sort(vector<int>& list, int i)
{
	if (i == list.size())
		return;
	int j = min_index(list, i);
	swap(list[i], list[j]);
	selection_sort(list, i + 1);	
}

// Prints the elements list[i]..list[n-1] recursively.
void print_list(vector<int> list, int i)
{
	if (i == list.size())
		cout << endl;
	else {
		cout << list[i] << ' ';
		print_list(list, i + 1);
	}
}

int main()
{
	vector<int> a;
	int x;
	while (cin >> x) {
		a.push_back(x);
	}
	
	// Sort and print the list of numbers. 
	// Note that the parameter i is set to zero to process the entire
	// elements.
	selection_sort(a, 0);
	print_list(a, 0);
}

