#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <errno.h>
 
#define PORT_NO 1234
     
typedef int Socket;
typedef pthread_t Thread;
void* do_server(void*);



int main(void) {
     
    
	Thread other_thread1;
Thread other_thread2;
     
  printf("%s", "Going to sleep...\n");
      sched_yield();
          sleep(2);
          
               
	int ret1 = pthread_create(&other_thread1, NULL, do_server, NULL);
printf("server thread1\n"); 
                 
        int ret2 = pthread_create(&other_thread2, NULL, do_server, NULL);  
printf("server thread2\n"); 
              
                            pthread_exit(NULL);
                                 
                                     return 0;
                                                      
                                                      }
													  
													  
													  
void* do_server(void* param)
 {
     
    printf("%s", "In server code...\n");
    struct in_addr localInterface;
	
struct sockaddr_in groupSock;
int sd;
//char databuf[1024] = "Multicast test message lol!";
//int datalen = sizeof(databuf);

/* Create a datagram socket on which to send. */
sd = socket(AF_INET, SOCK_DGRAM, 0);
if(sd < 0)
{
  perror("Opening datagram socket error");
  exit(1);
}
else
  printf("Opening the datagram socket...OK.\n");

/* Initialize the group sockaddr structure with a */
/* group address of 225.1.1.1 and port 5555. */
memset((char *) &groupSock, 0, sizeof(groupSock));
groupSock.sin_family = AF_INET;
groupSock.sin_addr.s_addr = inet_addr("226.1.1.1");
groupSock.sin_port = htons(4321);


localInterface.s_addr = INADDR_ANY;
if(setsockopt(sd, IPPROTO_IP, IP_MULTICAST_IF, (char *)&localInterface, sizeof(localInterface)) < 0)
{
  perror("Setting local interface error");
  exit(1);
}
else
  printf("Setting the local interface...OK\n");
/* Send a message to the multicast group specified by the*/
/* groupSock sockaddr structure. */
/*int datalen = 1024;*/
char databuf[1024];
char data[1024];
int datalen = sizeof(databuf);
FILE* fin=fopen("/proc/sys_call_count", "rt");
fgets(data, 70, fin);
strcpy(databuf, data);
if(sendto(sd, databuf, datalen, 0, (struct sockaddr*)&groupSock, sizeof(groupSock)) < 0)
{perror("Sending datagram message error");}
else
  printf("Sending datagram message...OK\n");


    pthread_exit(NULL);
}

