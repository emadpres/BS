#include <fstream>
#include <iostream>
#include <map>
#include "Porter.h"
#include "Dirent.h"
bool equal(char* a,char* b);
char* init()
{
	std::fstream *file=new std::fstream;
    char *temp=new char();
	char *ans=new char();
	char *final=new char();
	bool flag;
	std::map <char*,std::map<int,int> > hash;
	std::map<int,int> pair;
	std::map <char*,std::map<int,int>>::iterator iterate;
	std::map <char*,int> FileMap;
	DIR *pdir;
	struct dirent *FileDir;
	pdir=opendir("./File");
	if (!pdir)
	{
		printf ("opendir() failure; terminating");
		exit(1);
	}
	while ((FileDir=readdir(pdir)))
	{
		if(!strcmp(FileDir->d_name,".") || !strcmp(FileDir->d_name,"..") )
			continue;
		std::cout<<"Current : "<<FileDir->d_name<<"   Indexing... \n";	
		strcpy(temp,"./File/");
		strcat(temp,FileDir->d_name);
		new(file) std::fstream;
		file->open(temp,std::ios::in);
			if(!file->is_open())
				return 0;
			while(!file->eof())
			{
				file->getline(temp,2000);
				ans=strtok(temp," ;'><?/)(*&^%$#@!?");
				while(ans!=NULL)
				{
					flag=true;
					iterate=hash.begin();
					ans[stem(ans,0,strlen(ans)-1)+1]=0;
					for(int i=0;i<hash.size();i++)
					{
						if(equal(iterate->first,ans))
						{
							flag=false;
							break;
						}
						iterate++;
					}
					if(flag)
					{
						pair[1]=1;
						hash[strcpy(new char[strlen(ans)+1],ans)]=pair;
						pair.erase(pair.begin(),pair.end());	
					}
					ans=strtok(NULL," ;'><?/)(*&^%$#@!?");
				}
			}
			file->close();
	}
	closedir(pdir);
}
bool equal(char* a,char* b)
{
	if(strlen(a)<strlen(b))
	{
		for(int i=0;i<strlen(a);i++)
		{
			if (a[i]!=b[i])
				return false;
		}
	}
	else
	{
		for(int i=0;i<strlen(b);i++)
		{
			if (b[i]!=a[i])
				return false;
		}
	}
	return true;
}
int main()
{
	init();
	return 0;
}