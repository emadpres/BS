#include <stdio.h>
#include <pthread.h>

void * thread_function( void * arg )
{
	int * incoming = (int *) arg;
	// Do whatever is necessary using * incoming as the argument
	printf("incoming = %d\n", * incoming);
	return NULL;
}
int main ( void )
{
	pthread_t thread_ID;
	void * exit_status;
	int value = 42;
	pthread_create(&thread_ID, NULL, thread_function, &value);
	pthread_join(thread_ID, NULL);
	return 0;
}

