#include <stdio.h>
int main (void)
{
	printf("Happy new year!\n");
	return 0;
}

