#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
const int stack_size = 5;

int full_q;
pthread_mutex_t lock;
pthread_cond_t stack_full, stack_empty;

void * producer(void * arg)
{
	int wakeUp = 0;

	while(1)
	{
		pthread_mutex_lock(&lock);
		while(full_q == stack_size) pthread_cond_wait(&stack_full, &lock);
		full_q++;
		printf("Produced! Stack size: %d\n", full_q);
		//sleep(1);
		if (full_q == 1) wakeUp = 1;
		pthread_mutex_unlock(&lock);
		if (wakeUp) { wakeUp = 0; pthread_cond_signal(&stack_empty); }	
	}
	return NULL;
}

void * consumer(void * arg)
{
	int wakeUp = 0;

	while(1)
	{
		pthread_mutex_lock(&lock);
		while(full_q == 0) pthread_cond_wait(&stack_empty, &lock);
		full_q--;
		printf("Consumed! Stack size: %d\n", full_q);
		//sleep(1);
		if (full_q == stack_size - 1) wakeUp = 1;
		pthread_mutex_unlock(&lock);
		if(wakeUp) { wakeUp = 0; pthread_cond_signal(&stack_full); }
	}
	return NULL;
}

int main(void)
{
	void * es_prod; void * es_cons;
	pthread_t t_prod, t_cons;
	
	full_q = 0;
	pthread_mutex_init(&lock, NULL);
	pthread_cond_init(&stack_full, NULL);
	pthread_cond_init(&stack_empty, NULL);

	pthread_create(&t_prod, NULL, producer, NULL);
	pthread_create(&t_cons, NULL, consumer, NULL);

	pthread_join(t_prod, &es_prod);
	pthread_join(t_cons, &es_cons);

	return 0;
}
