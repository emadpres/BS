#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

void * thread_function ( void )
{
	char * buffer = (char *) malloc(64);
	// Fill up the buffer with something good
	strcpy(buffer, "Using pthreads is awesome!");

	return buffer;
}

int main ( void )
{
	pthread_t thread_ID;
	void * exit_status;
	
	pthread_create(&thread_ID, NULL, thread_function, NULL);
	pthread_join(thread_ID, &exit_status);
	
	printf("I got \'%s\' back from the thread.\n", (char *) exit_status);
	free(exit_status);
	return 0;
}
