#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>

int shared = 0;
sem_t binary_sem; // Used like a mutex

void * thread_function ( void * arg )
{
	sem_wait(&binary_sem); // Decrements count
	shared++;
	printf("Shared: %d\n", shared);
	sem_post(&binary_sem); // Increments count
	
	return NULL;
}

int main ( void )
{
	pthread_t thread_ID;
	
	sem_init(&binary_sem, 0, 1); // Give semaphore an initial count
	
	pthread_create(&thread_ID, NULL, thread_function, NULL);

	sem_wait(&binary_sem);
	shared--;
	printf("Shared: %d\n", shared);
	sem_post(&binary_sem);

	pthread_join(thread_ID, NULL);

	sem_destroy(&binary_sem);

	return 0;
}
