#include "OthelloBoard.h"
#include "OthelloItem.h"
#define BLACK 0
#define WHITE 1
#define EMPTY 2

OthelloBoard::OthelloBoard():QGraphicsRectItem(){}
void OthelloBoard::clicked(int row, int column){

	
		items[row][column]->setBrush(QBrush(QColor(Qt::black)));
	
	}

void OthelloBoard::initial()
{
	items[3][3]->setBrush(QBrush(QColor(Qt::black)));
	items[4][4]->setBrush(QBrush(QColor(Qt::black)));
	items[3][4]->setBrush(QBrush(QColor(Qt::white)));
	items[4][3]->setBrush(QBrush(QColor(Qt::white)));
}

