// Dima's try_bitboard_mobility3 function returning bitboard instead of #bits
void DimaMoves(const __int64 my_bits, const __int64 opp_bits);
// Dima's try_bitboard_mobility3 function
int DimaMobility(const __int64 my_bits, const __int64 opp_bits);